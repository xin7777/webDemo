//
// Created by mingj on 19-2-27.
//

#include "BaseProtocolItem.h"

std::string BaseProtocolItem::KEY_CODE = "code";

std::string BaseProtocolItem::KEY_DATA = "data";

std::string BaseProtocolItem::KEY_FILE_SIZE = "fileSize";

std::string BaseProtocolItem::KEY_CHUNK_SIZE = "chunkSize";