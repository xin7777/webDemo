//
// Created by mingj on 19-2-28.
//

#ifndef NDNIP_PROXY_NDN_CLIENT_H
#define NDNIP_PROXY_NDN_CLIENT_H


class ndn_client {

};


#endif //NDNIP_PROXY_NDN_CLIENT_H
