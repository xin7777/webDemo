//
// Created by mingj on 19-2-27.
//

#ifndef NDNIP_PROXY_NDN_IP_PROXY_H
#define NDNIP_PROXY_NDN_IP_PROXY_H


class ndn_ip_proxy {

};


#endif //NDNIP_PROXY_NDN_IP_PROXY_H
