echo "http://localhost/"$1
