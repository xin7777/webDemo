//
// Created by mingj on 19-2-27.
//

#ifndef NDNIP_PROXY_IP_CLIENT_H
#define NDNIP_PROXY_IP_CLIENT_H


class ip_client {

};


#endif //NDNIP_PROXY_IP_CLIENT_H
