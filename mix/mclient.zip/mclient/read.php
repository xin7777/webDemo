<?php

$source_name = $_POST['read'];
//$source_name = $_POST['name'];
echo $source_name;


?>
